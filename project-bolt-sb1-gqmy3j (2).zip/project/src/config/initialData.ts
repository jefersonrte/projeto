export const ADMIN_USER = {
  id: '1',
  email: 'jefersonrte@hotmail.com',
  password: 'qsc123456',
  name: 'Administrator',
  role: 'admin',
  createdAt: new Date().toISOString(),
  updatedAt: new Date().toISOString(),
} as const;